<?php
/**
 * Template Hooks related to site-content
 */
add_action( 'vodi_content_top', 'vodi_breadcrumb', 10 );